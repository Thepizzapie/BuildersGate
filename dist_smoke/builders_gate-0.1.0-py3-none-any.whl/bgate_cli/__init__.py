"""Builders Gate CLI + hooks."""
