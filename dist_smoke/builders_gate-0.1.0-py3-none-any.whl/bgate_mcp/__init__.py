"""Builders Gate MCP server."""
